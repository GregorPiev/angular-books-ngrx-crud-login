import { Component, OnInit, ViewChild } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Appstate } from '../../shared/store/appstate';
import { selectAppState } from 'src/app/shared/store/app.selector';
import { Observable } from 'rxjs';
import { Books } from '../store/books';
import { invokeBooksAPI, invokeDeleteBookAPI } from '../store/books.action';
import { selectBooks } from '../store/books.selector';
import { setAPIStatus } from 'src/app/shared/store/app.action';

import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';

declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  books$!: Observable<Books[]>;
  deleteModal: any;
  idToDelete: number = 0;

  displayedColumns: string[] =['id','name','author','cost','actions'];
  dataSource!: MatTableDataSource<Books>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;


  constructor(
    private store: Store,
    private appStore: Store<Appstate>
  ) { }

  ngOnInit(): void {
    this.store.dispatch(invokeBooksAPI());

    setTimeout(() => {
      // this.books$ = this.store.pipe(select(selectBooks));

      this.store.pipe(select(selectBooks)).subscribe((books)=>{
        console.log('Books:', books);
        if(books.length){
          this.dataSource = new MatTableDataSource<Books>(books);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }
      });


    }, 3000);
  }

  openDeleteModal(id: number):void{
    this.idToDelete = id;
    $('#deleteModal').modal('show');
  }

  close():void{
    $('#deleteModal').modal('hide');
  }

  delete(): void {
    this.store.dispatch(invokeDeleteBookAPI({ id: this.idToDelete }));
    let apiStatus$ = this.appStore.pipe(select(selectAppState));
    apiStatus$.subscribe((apState) => {
      if(apState.apiStatus =='success'){
        $('#deleteModal').modal('hide');
        this.appStore.dispatch(
          setAPIStatus({apiStatus:({apiResponseMessage: '', apiStatus: ''})})
        );
      }
    });
  }
}
