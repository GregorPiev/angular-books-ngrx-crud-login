import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, switchMap } from 'rxjs/operators';
import { AuthService } from '../auth.service';
import * as AuthActions from './auth.action';
import { of } from 'rxjs';
import { Store } from '@ngrx/store';
import { Appstate } from 'src/app/shared/store/appstate';
import { setAPIStatus } from 'src/app/shared/store/app.action';

@Injectable()
export class AuthEffects {

  constructor(
    private actions$: Actions,
    private authService: AuthService,
    private appStore: Store<Appstate>
  ) {}

  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.login),
      switchMap(action =>
        this.authService.login(action.username, action.password).pipe(
          map(
            token => {
              if(token == ''){
                this.appStore.dispatch(
                  setAPIStatus({
                    apiStatus: { apiResponseMessage: '', apiStatus: 'false' },
                  })
                );
              }else{
                this.appStore.dispatch(
                  setAPIStatus({
                    apiStatus: { apiResponseMessage: '', apiStatus: 'success' },
                  })
                );
              }
              return AuthActions.loginSuccess({ token })}
          ),
          catchError(
            error => of(AuthActions.loginFailure({ error }))
          )
        )
      )
    )
  );

  // Todo: Other effects for logout, token refresh, etc.

}
